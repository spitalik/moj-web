const CACHE = 'gamepad-v123';

const ASSETS = [
  './',
  './index.html',
  './i18n.js',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './games/snake/index.html',
  './games/brick-buster/index.html',
  './games/2048/index.html',
  './games/minesweeper/index.html',
  './games/asteroids/index.html',
  './games/dot-glider/index.html',
  './games/paddle-duel/index.html',
  './games/simon/index.html',
  './games/tower-defense/index.html',
  './games/platformer/index.html',
  './games/pexeso/index.html',
  './games/piskvory/index.html',
  './games/clickrush/index.html',
  './games/sudoku/index.html',
  './games/maze/index.html',
  './games/solitaire/index.html',
  './games/pipes/index.html',
  './games/nonogram/index.html',
  './games/blackjack/index.html',
  './games/road-hopper/index.html',
  './games/endless-runner/index.html',
  './games/alien-wave/index.html',
  './games/sliding-puzzle/index.html',
  './games/chess/index.html',
  './games/rhythm/index.html',
  './games/sand/index.html',
  './games/orbit-escape/index.html',
  './games/orbital-courier/index.html',
  './games/circuit-bloom/index.html',
  './games/echo-vault/index.html',
  './games/tiny-alchemist/index.html',
  './games/signal-garden/index.html',
  './games/dead-grid/index.html',
  './games/neon-lane/index.html',
  './games/sokoban/index.html',
  './games/ricochet/index.html',
  './games/flow/index.html',
  './games/stars/index.html',
  './games/gear-puzzle/index.html',
  './games/hill-racer/index.html',
  './games/top-racer/index.html',
  './games/nebula-strike/index.html',
  './games/gravity-shift/index.html',
  './games/cesty/index.html',
  './games/cosmic-voyager/index.html',
  './games/number-flash/index.html',
  './games/fluxgall/index.html',
  './games/threadcatch/index.html',
  './games/echodrift/index.html',
  './games/ninja-runner/index.html',
  './games/survival-arena/index.html',
  './games/one-bullet-dungeon/index.html',
  './games/binary-grid/index.html',
  './games/geoklik/index.html',
  './games/flag-quiz/index.html',
  './games/capital-quiz/index.html',
  './games/math-blitz/index.html',
  './games/twin-drop/index.html',
  './games/block-cascade/index.html',
  './games/gem-swap/index.html',
  './games/bubble-burst/index.html',
  './games/word-ladder/index.html',
  './games/word-weave/index.html',
  './games/ink-flood/index.html',
  './games/prism-path/index.html',
  './games/wobble-tower/index.html',
  './games/tilt-maze/index.html',
  './games/snip-rope/index.html',
  './games/type-rush/index.html',
  './games/whack-reflex/index.html',
  './games/gridlock-escape/index.html',
  './games/domino-drift/index.html',
  './games/kakuro-cross/index.html',
  './games/blackout-grid/index.html',
  './games/tangram-fit/index.html',
  './games/jigsaw-pieces/index.html',
  './games/peg-escape/index.html',
  './games/flip-tiles/index.html',
  './games/hanoi-towers/index.html',
  './games/cube-twist/index.html',
  './games/anagram-blitz/index.html',
  './games/crown-jump/index.html',
  './games/drop-four/index.html',
  './games/nine-mills/index.html',
  './games/dice-gates/index.html',
  './games/seed-sow/index.html',
  './games/box-claim/index.html',
  './games/stone-garden/index.html',
  './games/artillery-duel/index.html',
  './games/loop-weaver/index.html',
  './games/island-links/index.html',
  './games/lantern-halls/index.html',
  './games/shade-grid/index.html',
  './games/sign-grid/index.html',
  './games/code-breaker/index.html',
  './games/tile-match/index.html',
  './games/free-cells/index.html',
  './games/spider-cards/index.html',
  './games/pyramid-cards/index.html',
  './games/five-dice/index.html',
  './games/dot-muncher/index.html',
  './games/blast-maze/index.html',
  './games/sky-shield/index.html',
  './games/bug-column/index.html',
  './games/moon-lander/index.html',
  './games/light-trails/index.html',
  './games/mini-putt/index.html',
  './games/pool-break/index.html',
  './games/five-letters/index.html',
  './games/hidden-word/index.html',
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
  ));
  self.clients.claim();
});

self.addEventListener('message', e => {
  if (e.data === 'skipWaiting') self.skipWaiting();
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  const isPage = req.mode === 'navigate' || url.pathname.endsWith('.html');
  const isScript = url.pathname.endsWith('.js');

  if (isPage || isScript) {
    // Network-first: always prefer the freshest HTML/JS so newly added
    // games and i18n keys show up immediately without needing a manual
    // reload. Falls back to cache (then to the app shell) when offline.
    e.respondWith(
      fetch(req).then(res => {
        if (res.ok) {
          const clone = res.clone();
          caches.open(CACHE).then(c => c.put(req, clone));
        }
        return res;
      }).catch(() => caches.match(req).then(r => r || caches.match('./index.html')))
    );
    return;
  }

  // Cache-first for static assets (icons, etc.) — these rarely change.
  e.respondWith(
    caches.match(req).then(r => r || fetch(req).then(res => {
      if (res.ok) {
        const clone = res.clone();
        caches.open(CACHE).then(c => c.put(req, clone));
      }
      return res;
    }).catch(() => caches.match('./index.html')))
  );
});
